import { main } from "assets/jss/material-kit-pro-react.jsx";

const sectionsPageStyle = {
  main: {
    ...main
  }
};

export default sectionsPageStyle;
